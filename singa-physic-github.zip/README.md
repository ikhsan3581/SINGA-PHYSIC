# SINGA PHYSIC

Platform pembelajaran fisika dasar interaktif (Kelompok PDT 01).

## Struktur repo
```
index.html
assets/
  Star_Wars_Intro_HD_1080p.mp3   <- BGM (loop otomatis)
```

## Cara upload ke GitHub
1. Buat repository baru di github.com (mis. `singa-physic`).
2. Klik **Add file -> Upload files**, lalu seret `index.html` **dan folder `assets`** ke halaman upload. Klik **Commit changes**.
3. Buka **Settings -> Pages**. Pada *Source* pilih **Deploy from a branch**, branch `main`, folder `/ (root)`, lalu **Save**.
4. Tunggu 1-2 menit. Situs tersedia di `https://USERNAME.github.io/singa-physic/`.

## Ganti musik
Timpa file di `assets/` dengan nama yang sama, atau ubah konstanta `BGM_SRC` di `index.html`.
Nama file harus sama persis (huruf besar/kecil) dan sebaiknya tanpa spasi.
